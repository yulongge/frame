# mui

# obsolete! do not use it.

a ui framework for mobile webview app

## doc

<a href="http://html5beta.com/mui/">mui</a>

## license

MIT